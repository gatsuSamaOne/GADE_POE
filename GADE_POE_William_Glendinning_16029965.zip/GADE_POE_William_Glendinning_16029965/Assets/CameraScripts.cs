﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScripts : MonoBehaviour {


    //[SerializeField] private float posX = 50f;
    //[SerializeField] private float posY = 20f;
    //[SerializeField] private float posZ = 50f;
    //[SerializeField] private float mapSizeX = 5f;
    //[SerializeField] private float mapSizeY = 5f;
    //[SerializeField] private float mapSizeZ = 5f;

    // Use this for initialization
    void Start () {
		
	}

    public float panSpeed = 100f;
    public float panBorderThickness = 10f;
    public Vector3 panLimit;

    public float scrollSpeed = 30f;
    public float minY = 20f;
    public float maxY = 120f;

    // Update is called once per frame
    void Update ()
    {
        Vector3 pos = transform.position;

        if (Input.GetKey("w") || Input.mousePosition.y >= Screen.height - panBorderThickness)
        {
            pos.z += panSpeed * Time.deltaTime;
        }

        if (Input.GetKey("s") || Input.mousePosition.y <= panBorderThickness)
        {
            pos.z -= panSpeed * Time.deltaTime;
        }

        if (Input.GetKey("d") || Input.mousePosition.x >= Screen.width - panBorderThickness)
        {
            pos.x += panSpeed * Time.deltaTime;
        }

        if (Input.GetKey("a") || Input.mousePosition.x <= panBorderThickness)
        {
            pos.x -= panSpeed * Time.deltaTime;
        }

        float scroll = Input.GetAxis("Mouse ScrollWheel");
        pos.y -= scroll * scrollSpeed * 100f * Time.deltaTime;

        pos.x = Mathf.Clamp(pos.x, -panLimit.x, panLimit.x);
        pos.y = Mathf.Clamp(pos.y, minY, maxY);
        pos.z = Mathf.Clamp(pos.z, -panLimit.z, panLimit.z);


        transform.position = pos;

        //if (Input.GetKey (KeyCode.W) && gameObject.transform.position.z < mapSizeZ)
        //{
        //    gameObject.transform.position += new Vector3(0, 0, posZ * Time.deltaTime);
        //}

        //if (Input.GetKey (KeyCode.S) && gameObject.transform.position.z > -mapSizeZ)
        //{
        //    gameObject.transform.position += new Vector3(0, 0, -posZ * Time.deltaTime);
        //}

        //if (Input.GetKey(KeyCode.D) && gameObject.transform.position.x < mapSizeX)
        //{
        //    gameObject.transform.position += new Vector3(posX * Time.deltaTime, 0, 0);
        //}

        //if (Input.GetKey(KeyCode.A) && gameObject.transform.position.x > -mapSizeX)
        //{
        //    gameObject.transform.position += new Vector3(-posX * Time.deltaTime, 0, 0);
        //}

        //if (Input.GetKey(KeyCode.LeftShift) && gameObject.transform.position.y < mapSizeY)
        //{
        //    gameObject.transform.position += new Vector3(0, posY * Time.deltaTime, 0);
        //}

        //if (Input.GetKey(KeyCode.LeftControl) && gameObject.transform.position.y > 1)
        //{
        //    gameObject.transform.position += new Vector3(0, -posY * Time.deltaTime, 0);
        //}

    }
}
