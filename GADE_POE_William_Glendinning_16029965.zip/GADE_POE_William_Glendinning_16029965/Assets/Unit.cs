﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour {

	//public enum STATE { Idle, Moving, Combat };
 //   public STATE currentState;
 //   public TextMesh myStateText;

 //   public List<Unit> detected, enemies;


    
    // Use this for initialization
	void Start ()
    {
        //ChangeState(STATE.Idle);

        GameObject MeleeUnit_BLUE;
        MeleeUnit_BLUE = new GameObject("BLUE");
        MeleeUnit_BLUE.AddComponent<Rigidbody>();
        MeleeUnit_BLUE.AddComponent<BoxCollider>();

        GameObject MeleeUnit_RED;
        MeleeUnit_RED = new GameObject("RED");
        MeleeUnit_RED.AddComponent<Rigidbody>();
        MeleeUnit_RED.AddComponent<BoxCollider>();
    }


//public void ChangeState(STATE state)
//    {
//        currentState = state;
//    }
	
//	// Update is called once per frame
//	void Update () {
		
//	}
}
