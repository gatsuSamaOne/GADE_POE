﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile
{
    enum TileType { grass, water }

    int X, Y;
    TileType type;

    public Tile(int x, int y)
    {
        X = x;
        Y = y;

        type = TileType.grass;
    }
}

