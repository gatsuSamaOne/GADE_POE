﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementBlue4 : MonoBehaviour
{

    public GameObject mURed;
    public GameObject fBRed;
    public Vector3 startPos;
    public float dist;
    private int randomUnit;
    //public bool shouldMove;

    public float moveSpeed = 2.0f;

    public void Awake()
    {
        randomUnit = Random.Range(1, 4);
        mURed = GameObject.Find("MeleeUnit_RED_" + randomUnit.ToString());
        startPos = transform.position;
    }

    ////stops unit when comes into contact with other unit
    //public void OnCollisionEnter(Collision collision)
    //{
    //    if (collision.gameObject.name == "MeleeUnit_BLUE")
    //    {
    //        Debug.Log("Hit MeleeUnit_BLUE");
    //        shouldMove = false;
    //    }
    //}

    private void MovementControl()
    {
        dist = Vector3.Distance(mURed.transform.position, transform.position);

        if (dist < 200 && dist >= 5)
        {
            transform.LookAt(mURed.transform);
            transform.position = Vector3.MoveTowards(transform.position, mURed.transform.position, moveSpeed * Time.deltaTime);
        }

        else if (dist < 5)
        {
            transform.LookAt(startPos);
            transform.position = Vector3.MoveTowards(transform.position, startPos, moveSpeed * Time.deltaTime);
        }
    }

    public void Update()
    {
        MovementControl();
    }

}
