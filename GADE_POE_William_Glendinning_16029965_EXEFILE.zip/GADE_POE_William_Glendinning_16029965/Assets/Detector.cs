﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Detector : MonoBehaviour {

    public Unit myUnitRed;
    
    // Use this for initialization
	void Start ()
    {
        myUnitRed = gameObject.GetComponentInParent<Unit>();
    }


    // Update is called once per frame
    //	void Update ()
    //   {
    //    if (myUnitRed.enemies.Count > 0)
    //       {
    //           myUnitRed.enemies.Clear();
    //       }

    //       foreach (unit detectedObject in myUnitRed.detected)
    //       {
    //           if (detectedObject == null)
    //           {
    //               myUnitRed.detected.Remove(detectedObject);
    //           }

    //           if (detectedObect.tag == "BlueUnit")
    //           {
    //               myUnitRed.enemies.Add(detectedObject);
    //           }
    //       }

    //       //if (myUnitRed.currentState != Unit.STATE.Moving)
    //}
}
