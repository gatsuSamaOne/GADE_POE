﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map {

    Tile[,] mapTiles;
    string fileName;

    int width;
    int height;

    public Map (int width = 100, int height = 100)
    {
        this.width = width;
        this.height = height;

        mapTiles = new Tile[width, height];

        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                mapTiles[i, j] = new Tile(i, j);
            }
        }
    }

    public void loadFromFile (string fileName)
    {

    }
}
