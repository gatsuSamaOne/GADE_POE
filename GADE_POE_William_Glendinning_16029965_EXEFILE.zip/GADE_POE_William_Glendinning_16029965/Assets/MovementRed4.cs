﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementRed4 : MonoBehaviour
{
    public GameObject mUBLUE;
    public Vector3 startPos;
    public float dist;
    public bool shouldMove;
    private int randomUnit;

    public float moveSpeed = 2.0f;

    public void Awake()
    {
        randomUnit = Random.Range(1, 4);
        mUBLUE = GameObject.Find("MeleeUnit_BLUE_" + randomUnit.ToString());
        startPos = transform.position;
    }

    ////stops unit when comes into contact with other unit
    //public void OnCollisionEnter(Collision collision)
    //{
    //    if (collision.gameObject.name == "MeleeUnit_BLUE")
    //    {
    //        Debug.Log("Hit MeleeUnit_BLUE");
    //        shouldMove = false;
    //    }
    //}

    private void MovementControl()
    {
        dist = Vector3.Distance(mUBLUE.transform.position, transform.position);

        if (dist < 200 && dist >= 5)
        {
            transform.LookAt(mUBLUE.transform);
            transform.position = Vector3.MoveTowards(transform.position, mUBLUE.transform.position, moveSpeed * Time.deltaTime);
        }

        else if (dist < 5)
        {
            transform.LookAt(startPos);
            transform.position = Vector3.MoveTowards(transform.position, startPos, moveSpeed * Time.deltaTime);
        }
    }


    public void Update()
    {
        MovementControl();
    }
}