﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RealTimeStrategyGame
{
    public partial class RealTimeStrategyGame : Form
    {
        int timer = 0;

        public RealTimeStrategyGame()
        {
            InitializeComponent();
            lblTime.Text = "Time: " + Convert.ToString(timer);
        }

        GameEngine engine = new GameEngine();

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            lblTime.Text = "Time: " + Convert.ToString(timer);
            engine.start();

            lblMap.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    lblMap.Text += engine.map.grid[i, j] + " ";
                }
                lblMap.Text += "\n";
            }

            engine.map.ResourceRed.produceResources();
            lblRedResource.Text = Convert.ToString(engine.map.ResourceRed.resourceAmount) + " Gold";

            engine.map.ResourceBlue.produceResources();
            lblBlueResource.Text = Convert.ToString(engine.map.ResourceBlue.resourceAmount) + " Gold";
            timer++;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnPause.Enabled = true;
            btnStart.Enabled = false;
            timerSeconds.Enabled = true;
            engine.map.populate();
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            btnPause.Enabled = false;
            btnStart.Enabled = true;
            timerSeconds.Enabled = false;
        }

        private void RealTimeStrategyGame_Load(object sender, EventArgs e)
        {
            timerSeconds.Enabled = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
                Application.Exit();
        }

        private void lblMap_Click(object sender, EventArgs e)
        {
            int mouseX = MousePosition.X;
            int mouseY = MousePosition.Y;

            int formX = this.Location.X;
            int formY = this.Location.Y;

            int y = (mouseX - formX - 20 - 5) / 15;
            int x = (mouseY - formY - 40 - 1) / 15;

            txtDisplay.Text = " ";
            foreach (Unit u in engine.map.UnitsOnMap)
            {
                if (u.X == x && u.Y == y)
                {
                    txtDisplay.Text += u.toString();
                }
            }
        }

        private void lblResource_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            engine.save();
            
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            engine.load();
            engine.map.LoadedMap();
            
            

            lblMap.Text = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    lblMap.Text += engine.map.grid[i, j] + " ";
                }
                lblMap.Text += "\n";
            }
            
        }
    }
}
