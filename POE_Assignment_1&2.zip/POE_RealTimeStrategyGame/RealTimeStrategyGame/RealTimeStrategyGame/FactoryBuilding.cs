﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeStrategyGame
{
    class FactoryBuilding : Building
    {
        public int productionPerTick = 4;
        public int unitsSpawnPoint = 10;
        public int unitsToProduce = 5;
        public int spawnPointX;
        public int spawnPointY;

        public FactoryBuilding(int x, int y, int health, string faction, string image)
            : base(x, y, health, faction, image)
        {
        }

        public Unit spawnNewUnit()
        {
            spawnPointX = this.x + 1;
            spawnPointY = this.y + 1;
            if (unitsToProduce > 0)
            {
                Random rnd = new Random();
                if (rnd.Next(0, 2) == 0)
                {
                    //MeleeUnit
                    MeleeUnit mU = new MeleeUnit(spawnPointX, spawnPointY, 100, -1, true, 1, this.Faction, "M", "Knight");
                    unitsToProduce--;
                    return mU;
                }
                else
                {
                    // RangedUnit
                    RangedUnit rU = new RangedUnit(spawnPointX, spawnPointY, 100, -1, true, 5, this.Faction, "R", "Archer");
                    unitsToProduce--;
                    return rU;
                }
            }
            else
                return null;
        }

        public override bool isAlive()
        {
            if (this.health <= 0)
                return false;
            else
                return true;
        }

        public override string toString()
        {
            string output = "x : " + X + Environment.NewLine
                + "y : " + Y + Environment.NewLine
                + "Health : " + health + Environment.NewLine
                + "Faction : " + faction + Environment.NewLine
                + "Image : " + image + Environment.NewLine;
            return output;
        }
    }
}
