﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeStrategyGame
{
    class Map
    {
        private const int MAX_RANDOM_UNITS = 50;
        public const string FIELD_SYMBOL = ".";        
        public string[,] grid = new string[20, 20];
        private List<Unit> unitsOnMap = new List<Unit>();
        private int numberOfUnitsOnMap = 0;

        ResourceBuilding resourceRed = new ResourceBuilding(2, 4, 50, "RED", "BR");
        ResourceBuilding resourceBlue = new ResourceBuilding(18, 4, 50, "BLUE", "BB");
        FactoryBuilding resourceFacRed = new FactoryBuilding(2, 5, 50, "RED", "FR");
        FactoryBuilding resourceFacBlue = new FactoryBuilding(18, 5, 50, "BLUE", "FB");

        public int NumberOfUnitsOnMap
        {
            get { return numberOfUnitsOnMap; }
            set { numberOfUnitsOnMap = value; }
        }

        public ResourceBuilding ResourceRed
        {
            get { return resourceRed; }
            set { resourceRed = value; }
        }

        public ResourceBuilding ResourceBlue
        {
            get { return resourceBlue; }
            set { resourceBlue = value; }
        }

        public FactoryBuilding ResourceFacRed
        {
            get { return resourceFacRed; }
            set { resourceFacRed = value; }
        }

        public FactoryBuilding ResourceFacBlue
        {
            get { return resourceFacBlue; }
            set { resourceFacBlue = value; }
        }

        public List<Unit> UnitsOnMap
        {
            get
            {
                return unitsOnMap;
            }
            set
            {
                unitsOnMap = value;
            }
        }

        public string[,] Grid
        {
            get
            {
                return grid;
            }
        }

        public void LoadedMap()
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = FIELD_SYMBOL;
                }
            }

            int x, y;

            x = resourceRed.X;
            y = resourceRed.Y;
            grid[x, y] = resourceRed.Image;

            x = resourceBlue.X;
            y = resourceBlue.Y;
            grid[x, y] = resourceBlue.Image;

            x = resourceFacRed.X;
            y = resourceFacRed.Y;
            grid[x, y] = resourceFacRed.Image;

            x = resourceFacBlue.X;
            y = resourceFacBlue.Y;
            grid[x, y] = resourceFacBlue.Image;

            Console.WriteLine(unitsOnMap.Count);

            foreach (Unit u in unitsOnMap)
            {
                x = u.X;
                y = u.Y;

                grid[x, y] = u.Symbol;
                Console.WriteLine(u.X + " : " + u.Y + " : " + u.Symbol);
            }
        }

        public void populate()
        {
            Random rnd = new Random();
            int numberRandomUnits = rnd.Next(0, MAX_RANDOM_UNITS) + 1;
            int x, y, randomAttackRange;
            bool attackOption;
            string team;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)

                {
                    grid[i, j] = FIELD_SYMBOL;
                }
            }

           x = resourceRed.X;
            y = resourceRed.Y;
            grid[x, y] = resourceRed.Image;

            x = resourceBlue.X;
            y = resourceBlue.Y;
            grid[x, y] = resourceBlue.Image;

            x = resourceFacRed.X;
            y = resourceFacRed.Y;
            grid[x, y] = resourceFacRed.Image;

            x = resourceFacBlue.X;
            y = resourceFacBlue.Y;
            grid[x, y] = resourceFacBlue.Image;


            for (int k = 1; k <= numberRandomUnits; k++)
            {
                do
                {
                    x = rnd.Next(0, 20);
                    y = rnd.Next(0, 20);
                }
                while (grid[x, y] != FIELD_SYMBOL);

                if (rnd.Next(1, 3) == 1)
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;
                    team = rnd.Next(0, 2) == 1 ? "RED" : "BLUE";
                    Unit tmp = new MeleeUnit(x, y, 100, -1, attackOption, 1, team, "M", "Knight");
                    unitsOnMap.Add(tmp);

                    grid[x, y] = tmp.Symbol;

                    numberOfUnitsOnMap++;
                }

                else
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;
                    randomAttackRange = rnd.Next(1, 6);
                    team = rnd.Next(0, 2) == 1 ? "RED" : "BLUE";
                    Unit tmp = new RangedUnit(x, y, 100, -1, attackOption, randomAttackRange, team, "R", "Archer");
                    unitsOnMap.Add(tmp);

                    grid[x, y] = tmp.Symbol;

                    numberOfUnitsOnMap++;
                }
            }
            foreach (Unit u in unitsOnMap)
            {
                x = u.X;
                y = u.Y;

                grid[x, y] = u.Symbol;
                Console.WriteLine(u.X + " : " + u.Y + " : " + u.Symbol);
            }
        }

        private void moveOnMap(Unit u, int posX, int posY)
        {
            grid[u.X, u.Y] = FIELD_SYMBOL;
            grid[posX, posY] = u.Symbol;
        }

        public void update(Unit u, int posX, int posY)
        {
            if ((posX >= 0 && posX < 20) && (posY >= 0 && posY <20) && (grid[posX, posY] == FIELD_SYMBOL))
            {
                moveOnMap(u, posX, posY);
                u.move(posX, posY);
            }
        }

        public void checkHealth()
        {
            for (int i = 0; i < numberOfUnitsOnMap; i++)
            {
                if (!unitsOnMap[i].isAlive())
                {
                    grid[unitsOnMap[i].X, unitsOnMap[i].Y] = FIELD_SYMBOL;
                    unitsOnMap.RemoveAt(i);
                    numberOfUnitsOnMap--;
                }
            }
        }           
    }
}
