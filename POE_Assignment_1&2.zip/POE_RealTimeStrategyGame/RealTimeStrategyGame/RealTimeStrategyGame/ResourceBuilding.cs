﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeStrategyGame
{
    class ResourceBuilding : Building
    {
        public string resourceType = "Gold";
        public int resourceAmount = 0;
        public int resourceProduced = 10;
        public int cost = 50;

        public ResourceBuilding(int x, int y, int health,  string faction, string image)
            : base(x, y, health, faction, image)
        {
        }

        public int produceResources()
        {
            resourceAmount = resourceAmount + resourceProduced;
            return resourceAmount;
        }

        public int consumeResources()
        {
            resourceAmount = resourceAmount - cost;
            return resourceAmount;
        }

        public override bool isAlive()
        {
            if (this.health <= 0)
                return false;
            else
                return true;
        }

        public override string toString()
        {
            string output = "x : " + X + Environment.NewLine
                + "y : " + Y + Environment.NewLine
                + "Health : " + health + Environment.NewLine
                + "Faction : " + faction + Environment.NewLine
                + "Image : " + image + Environment.NewLine;
            return output;
        }
    }
}
