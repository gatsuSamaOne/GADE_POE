﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RealTimeStrategyGame
{
    class GameEngine
    {
        public Map map = new Map();

        public GameEngine()
        {
            
        }

        public void save()
        {
            try
            {
                FileStream outFile = new FileStream("Unit_Info.txt", FileMode.Create, FileAccess.Write);
                StreamWriter write = new StreamWriter(outFile);

                foreach (Unit u in map.UnitsOnMap)
                {
                    write.WriteLine(u.Name);
                    write.WriteLine(u.X);
                    write.WriteLine(u.Y);
                    write.WriteLine(u.Health);
                    write.WriteLine(u.Speed);
                    write.WriteLine(u.Attack);
                    write.WriteLine(u.AttackRange);
                    write.WriteLine(u.Faction);
                    write.WriteLine(u.Symbol);

                }
                write.Close();
                outFile.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine(fe.Message);
            }
        }

        public void load()
        {
            string unitInformation;

            map.UnitsOnMap.Clear();
            try
            {

                FileStream inFile = new FileStream("Unit_Info.txt", FileMode.Open, FileAccess.Read);
                StreamReader read = new StreamReader(inFile);

                unitInformation = read.ReadLine();
                while (unitInformation != null)
                {
                    if (unitInformation.Equals("Knight"))
                    {
                        Unit tmp = new MeleeUnit(
                            int.Parse(read.ReadLine()),
                            int.Parse(read.ReadLine()),
                            int.Parse(read.ReadLine()),
                            int.Parse(read.ReadLine()),
                            bool.Parse(read.ReadLine()),
                            int.Parse(read.ReadLine()),
                            read.ReadLine(),
                            read.ReadLine(),
                            unitInformation);

                        map.UnitsOnMap.Add(tmp);
                        map.NumberOfUnitsOnMap++;
                        //map.Grid[tmp.X, tmp.Y] = tmp.Symbol;
                        Console.WriteLine("Knight");
                    }
                    else if (unitInformation.Equals("Archer"))
                    {
                        
                        Unit tmp = new RangedUnit(
                            int.Parse(read.ReadLine()),
                            int.Parse(read.ReadLine()),
                            int.Parse(read.ReadLine()),
                            int.Parse(read.ReadLine()),
                            bool.Parse(read.ReadLine()),
                            int.Parse(read.ReadLine()),
                            read.ReadLine(),
                            read.ReadLine(),
                            unitInformation);

                        map.UnitsOnMap.Add(tmp);
                        map.NumberOfUnitsOnMap++;
                        //map.Grid[tmp.X, tmp.Y] = tmp.Symbol;
                        Console.WriteLine("Archer");
                    }
                    unitInformation = read.ReadLine();
                }
                Console.WriteLine(map.UnitsOnMap.Count);
                inFile.Close();
                read.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine(fe.Message);
            }
        }

        public void start()
        {
            int newPosX, newPosY;
            Unit closet;

            map.checkHealth();

            // problem below

            for(int j = 0; j < map.UnitsOnMap.Count; j++)
            {
                if (!map.UnitsOnMap[j].Attack)
                {
                    closet = map.UnitsOnMap[j].closetUnit(map.UnitsOnMap);

                    if (map.UnitsOnMap[j].X < closet.X)
                        newPosX = map.UnitsOnMap[j].X + 1;
                    else if (map.UnitsOnMap[j].X > closet.X)
                        newPosX = map.UnitsOnMap[j].X - 1;
                    else newPosX = map.UnitsOnMap[j].X;

                    if (map.UnitsOnMap[j].Y < closet.Y)
                        newPosY = map.UnitsOnMap[j].Y + 1;
                    else if (map.UnitsOnMap[j].Y > closet.Y)
                        newPosY = map.UnitsOnMap[j].Y - 1;
                    else newPosY = map.UnitsOnMap[j].Y;

                    map.update(map.UnitsOnMap[j], newPosX, newPosY);
                }

                if (map.UnitsOnMap[j].Attack)
                {
                    for (int i = 0; i < map.UnitsOnMap.Count; i++)
                    {
                        if (map.UnitsOnMap[j].Faction != map.UnitsOnMap[i].Faction)
                            map.UnitsOnMap[j].combat(map.UnitsOnMap[i]);
                    }
                }

                if (!map.UnitsOnMap[j].Attack)
                {
                    for (int i = 0; i < map.UnitsOnMap.Count; i++)
                    {
                        if ((map.UnitsOnMap[j].Faction != map.UnitsOnMap[i].Faction) && (map.UnitsOnMap[j].Faction != map.UnitsOnMap[i].Faction))
                            map.UnitsOnMap[j].Attack = true;
                    }
                }
                
                if (map.UnitsOnMap[j].Health < 25)
                {
                    newPosX = map.UnitsOnMap[j].X + 1;
                    newPosY = map.UnitsOnMap[j].Y - 1;
                    map.update(map.UnitsOnMap[j], newPosX, newPosY);
                }
                map.checkHealth();
            }            
        }
    }
}
